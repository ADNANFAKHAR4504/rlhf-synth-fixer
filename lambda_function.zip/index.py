import json
import boto3
import os
from aws_xray_sdk.core import xray_recorder
from aws_xray_sdk.core import patch_all

# Patch AWS SDK calls for X-Ray tracing
patch_all()

dynamodb = boto3.resource('dynamodb')

@xray_recorder.capture('lambda_handler')
def lambda_handler(event, context):
    try:
        table = dynamodb.Table(os.environ.get('DYNAMODB_TABLE', 'tap-serverless-table'))
        
        # Sample logic - echo the request with timestamp
        response_body = {
            'message': 'Hello from Lambda!',
            'event': event,
            'table_name': os.environ.get('DYNAMODB_TABLE', 'tap-serverless-table')
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response_body)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }