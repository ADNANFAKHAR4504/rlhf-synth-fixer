import boto3
import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
ec2 = boto3.client('ec2')

def handler(event, context):
    try:
        detail = event['detail']
        if detail['eventName'] not in ['AuthorizeSecurityGroupIngress', 'RevokeSecurityGroupIngress']:
            return
        
        sg_id = detail['requestParameters']['groupId']
        response = ec2.describe_security_groups(GroupIds=[sg_id])
        sg = response['SecurityGroups'][0]
        
        for rule in sg['IpPermissions']:
            if rule.get('FromPort') in [22, 3389]:
                for ip_range in rule.get('IpRanges', []):
                    if ip_range.get('CidrIp') == '0.0.0.0/0':
                        logger.warning(f"Removing dangerous rule from {sg_id}: {rule}")
                        ec2.revoke_security_group_ingress(GroupId=sg_id, IpPermissions=[rule])
                        
        return {'statusCode': 200, 'body': 'Remediation complete'}
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return {'statusCode': 500, 'body': str(e)}
