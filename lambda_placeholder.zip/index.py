# Lambda placeholder
