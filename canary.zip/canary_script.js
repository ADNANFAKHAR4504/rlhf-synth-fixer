const synthetics = require('Synthetics');
const log = require('SyntheticsLogger');

const apiCanary = async function () {
    log.info('Starting canary test...');
    const page = await synthetics.getPage();
    
    // Simple health check
    const response = await page.goto('https://example.com', {
        waitUntil: 'domcontentloaded',
        timeout: 30000
    });
    
    if (!response || response.status() !== 200) {
        throw new Error('Health check failed');
    }
    
    log.info('Canary test passed');
};

exports.handler = async () => {
    return await apiCanary();
};
