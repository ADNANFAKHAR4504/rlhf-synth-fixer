import json
import os
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')
table_name = os.environ.get('DYNAMODB_TABLE', '')
table = dynamodb.Table(table_name) if table_name else None

def handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        transaction_id = body.get('transactionId')
        customer_id = body.get('customerId')
        amount = body.get('amount')
        
        if not all([transaction_id, customer_id, amount]):
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing required fields'})}
        
        if table:
            timestamp = int(datetime.now().timestamp())
            table.put_item(Item={
                'transactionId': transaction_id,
                'timestamp': timestamp,
                'customerId': customer_id,
                'amount': str(amount),
                'status': 'PROCESSED',
                'processedAt': datetime.now().isoformat()
            })
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Payment processed successfully', 'transactionId': transaction_id})
        }
    except Exception as e:
        print(f'Error: {str(e)}')
        return {'statusCode': 500, 'body': json.dumps({'error': 'Internal server error'})}
