"""Shared utilities for payment processing."""

def format_currency(amount):
    """Format amount as currency."""
    return f"${amount:.2f}"

def validate_transaction_id(transaction_id):
    """Validate transaction ID format."""
    return len(transaction_id) > 0 and transaction_id.isalnum()
