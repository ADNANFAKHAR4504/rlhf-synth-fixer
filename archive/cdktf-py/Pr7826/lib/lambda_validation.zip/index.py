import json

def handler(event, context):
    """Validation Lambda handler"""
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Validation successful', 'event': event})
    }
