import json
import boto3
import logging
import random
import string
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def handler(event, context):
    """
    Lambda function to handle custom secret rotation for API keys and credentials.
    """
    try:
        secrets_manager = boto3.client('secretsmanager')
        
        # Get secret details from event
        secret_arn = event.get('Step1', {}).get('SecretId', '')
        token = event.get('Step1', {}).get('ClientRequestToken', '')
        step = event.get('Step1', {}).get('Step', 'createSecret')
        
        logger.info(f"Starting rotation step: {step} for secret: {secret_arn}")
        
        if step == 'createSecret':
            create_secret(secrets_manager, secret_arn, token)
        elif step == 'setSecret':
            set_secret(secrets_manager, secret_arn, token)
        elif step == 'testSecret':
            test_secret(secrets_manager, secret_arn, token)
        elif step == 'finishSecret':
            finish_secret(secrets_manager, secret_arn, token)
        
        return {'statusCode': 200, 'body': json.dumps('Success')}
        
    except Exception as e:
        logger.error(f"Error during rotation: {str(e)}")
        return {'statusCode': 500, 'body': json.dumps(f'Error: {str(e)}')}

def create_secret(secrets_manager, secret_arn, token):
    """Create a new version of the secret with new credentials."""
    try:
        current_secret = secrets_manager.get_secret_value(SecretArn=secret_arn, VersionStage='AWSCURRENT')
        current_data = json.loads(current_secret['SecretString'])
        
        # Generate new credentials
        new_data = current_data.copy()
        if 'external_api_key' in new_data:
            new_data['external_api_key'] = generate_api_key()
        if 'internal_api_key' in new_data:
            new_data['internal_api_key'] = generate_api_key()
        if 'jwt_secret' in new_data:
            new_data['jwt_secret'] = generate_jwt_secret()
            
        secrets_manager.put_secret_value(
            SecretArn=secret_arn,
            ClientRequestToken=token,
            SecretString=json.dumps(new_data),
            VersionStage='AWSPENDING'
        )
        logger.info("Created new secret version")
        
    except Exception as e:
        logger.error(f"Error creating secret: {str(e)}")
        raise

def set_secret(secrets_manager, secret_arn, token):
    """Configure the service to use the new secret."""
    logger.info("Setting secret in service (placeholder implementation)")
    # Placeholder for actual service configuration
    pass

def test_secret(secrets_manager, secret_arn, token):
    """Test the new secret to ensure it works."""
    logger.info("Testing new secret (placeholder implementation)")
    # Placeholder for actual secret testing
    pass

def finish_secret(secrets_manager, secret_arn, token):
    """Finalize the rotation by updating version stages."""
    try:
        secrets_manager.update_secret_version_stage(
            SecretArn=secret_arn,
            VersionStage='AWSCURRENT',
            MoveToVersionId=token,
            RemoveFromVersionId=secrets_manager.describe_secret(SecretArn=secret_arn)['VersionIdsToStages']['AWSCURRENT'][0]
        )
        logger.info("Finished secret rotation")
        
    except Exception as e:
        logger.error(f"Error finishing secret: {str(e)}")
        raise

def generate_api_key(length=32):
    """Generate a secure API key."""
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

def generate_jwt_secret(length=64):
    """Generate a secure JWT secret."""
    characters = string.ascii_letters + string.digits + '!@#$%^&*'
    return ''.join(random.choice(characters) for _ in range(length))
