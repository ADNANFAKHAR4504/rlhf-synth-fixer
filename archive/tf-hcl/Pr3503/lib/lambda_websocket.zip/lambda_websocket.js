const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const { connectionId, routeKey } = event.requestContext;
    const tableName = process.env.CONNECTIONS_TABLE;

    try {
        switch (routeKey) {
            case '$connect':
                await dynamodb.put({
                    TableName: tableName,
                    Item: {
                        connectionId: connectionId,
                        timestamp: new Date().toISOString()
                    }
                }).promise();
                return { statusCode: 200, body: 'Connected' };

            case '$disconnect':
                await dynamodb.delete({
                    TableName: tableName,
                    Key: { connectionId: connectionId }
                }).promise();
                return { statusCode: 200, body: 'Disconnected' };

            case '$default':
                // Handle default messages
                const message = JSON.parse(event.body);
                console.log('Received message:', message);

                // Here you would typically process the message
                // and potentially broadcast to other connections

                return { statusCode: 200, body: 'Message received' };

            default:
                return { statusCode: 400, body: 'Unknown route' };
        }
    } catch (error) {
        console.error('Error:', error);
        return { statusCode: 500, body: 'Internal server error' };
    }
};