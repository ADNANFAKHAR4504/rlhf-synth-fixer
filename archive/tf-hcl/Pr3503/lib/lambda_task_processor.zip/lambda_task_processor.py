import json
import boto3
import os
from datetime import datetime

def handler(event, context):
    """
    Process scheduled tasks for project management platform.
    This function handles deadline reminders, task notifications, and reports.
    """
    print(f"Processing scheduled task: {json.dumps(event)}")

    # Get task type from event
    task_type = event.get('taskType', 'unknown')

    # Initialize AWS clients
    sns = boto3.client('sns')
    dynamodb = boto3.resource('dynamodb')
    secrets_manager = boto3.client('secretsmanager')

    # Process based on task type
    if task_type == 'deadline_reminder':
        # Send deadline reminder notifications
        message = f"Project deadline reminder: {event.get('message', 'No message')}"
        sns.publish(
            TopicArn=os.environ['SNS_TOPIC_ARN'],
            Subject='Project Deadline Reminder',
            Message=message
        )
    elif task_type == 'daily_report':
        # Generate and send daily reports
        message = f"Daily project report generated at {datetime.now()}"
        sns.publish(
            TopicArn=os.environ['SNS_TOPIC_ARN'],
            Subject='Daily Project Report',
            Message=message
        )
    elif task_type == 'task_notification':
        # Send task assignment notifications
        message = f"Task notification: {event.get('message', 'No message')}"
        sns.publish(
            TopicArn=os.environ['SNS_TOPIC_ARN'],
            Subject='Task Assignment',
            Message=message
        )

    # Log task execution
    table = dynamodb.Table(os.environ['TASK_TABLE'])
    table.put_item(
        Item={
            'taskId': event.get('taskId', 'unknown'),
            'executedAt': datetime.now().isoformat(),
            'taskType': task_type,
            'status': 'completed'
        }
    )

    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': f'Task {task_type} processed successfully',
            'timestamp': datetime.now().isoformat()
        })
    }
