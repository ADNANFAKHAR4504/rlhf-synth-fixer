import json
import boto3
import os
from datetime import datetime
import io
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')
config = boto3.client('config')

DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE']
REPORTS_BUCKET = os.environ['REPORTS_BUCKET']
SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN']

def handler(event, context):
    """
    Process Terraform state files and evaluate compliance
    """
    table = dynamodb.Table(DYNAMODB_TABLE)

    # Get list of state files from S3
    state_bucket = event.get('state_bucket', 'terraform-states')
    state_key = event.get('state_key', 'terraform.tfstate')

    try:
        # Read state file
        response = s3.get_object(Bucket=state_bucket, Key=state_key)
        state_content = json.loads(response['Body'].read())

        # Extract resources
        resources = extract_resources(state_content)

        # Evaluate compliance for each resource
        compliance_results = []
        for resource in resources:
            result = evaluate_resource_compliance(resource)
            compliance_results.append(result)

            # Store in DynamoDB
            store_compliance_result(table, result)

            # Check for critical non-compliance
            if result.get('severity', 0) > 8:
                send_critical_alert(result)

        # Generate PDF report
        report_key = generate_pdf_report(compliance_results)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Compliance scan completed',
                'resources_scanned': len(resources),
                'report_location': f's3://{REPORTS_BUCKET}/{report_key}'
            })
        }

    except Exception as e:
        print(f"Error processing state file: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def extract_resources(state_content):
    """Extract resources from Terraform state file"""
    resources = []

    if 'resources' in state_content:
        for resource in state_content['resources']:
            resources.append({
                'type': resource.get('type'),
                'name': resource.get('name'),
                'id': resource.get('instances', [{}])[0].get('attributes', {}).get('id'),
                'attributes': resource.get('instances', [{}])[0].get('attributes', {})
            })

    return resources

def evaluate_resource_compliance(resource):
    """Evaluate resource against compliance rules"""
    compliance_status = 'COMPLIANT'
    severity = 0
    issues = []

    resource_type = resource.get('type', '')
    attributes = resource.get('attributes', {})

    # EC2 Instance Type Check
    if resource_type == 'aws_instance':
        instance_type = attributes.get('instance_type', '')
        if instance_type.startswith('t2.'):
            compliance_status = 'NON_COMPLIANT'
            severity = 5
            issues.append('Legacy instance type detected')

    # S3 Bucket Encryption Check
    elif resource_type == 'aws_s3_bucket':
        encryption = attributes.get('server_side_encryption_configuration')
        if not encryption:
            compliance_status = 'NON_COMPLIANT'
            severity = 9
            issues.append('S3 bucket encryption not enabled')

    # RDS Backup Retention Check
    elif resource_type == 'aws_db_instance':
        backup_retention = attributes.get('backup_retention_period', 0)
        if backup_retention < 7:
            compliance_status = 'NON_COMPLIANT'
            severity = 8
            issues.append('RDS backup retention period less than 7 days')

    return {
        'resource_id': resource.get('id', 'unknown'),
        'resource_type': resource_type,
        'resource_name': resource.get('name', 'unknown'),
        'compliance_status': compliance_status,
        'rule_name': f'{resource_type}_compliance_check',
        'timestamp': int(datetime.now().timestamp()),
        'severity': severity,
        'issues': issues
    }

def store_compliance_result(table, result):
    """Store compliance result in DynamoDB"""
    table.put_item(Item=result)

def send_critical_alert(result):
    """Send SNS notification for critical non-compliance"""
    message = f"""
    Critical Compliance Issue Detected

    Resource ID: {result['resource_id']}
    Resource Type: {result['resource_type']}
    Status: {result['compliance_status']}
    Severity: {result['severity']}
    Issues: {', '.join(result['issues'])}

    Immediate action required.
    """

    sns.publish(
        TopicArn=SNS_TOPIC_ARN,
        Subject='Critical Compliance Alert',
        Message=message
    )

def generate_pdf_report(compliance_results):
    """Generate PDF compliance report"""
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)

    # Report header
    c.setFont("Helvetica-Bold", 16)
    c.drawString(100, 750, "Infrastructure Compliance Report")

    c.setFont("Helvetica", 12)
    c.drawString(100, 730, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    # Summary
    total_resources = len(compliance_results)
    compliant = sum(1 for r in compliance_results if r['compliance_status'] == 'COMPLIANT')
    non_compliant = total_resources - compliant

    c.drawString(100, 700, f"Total Resources Scanned: {total_resources}")
    c.drawString(100, 680, f"Compliant: {compliant}")
    c.drawString(100, 660, f"Non-Compliant: {non_compliant}")

    # Detailed results
    y_position = 620
    for result in compliance_results[:20]:  # Limit to first 20 for space
        if result['compliance_status'] == 'NON_COMPLIANT':
            c.setFont("Helvetica-Bold", 10)
            c.drawString(100, y_position, f"{result['resource_type']}: {result['resource_name']}")
            y_position -= 15
            c.setFont("Helvetica", 9)
            c.drawString(120, y_position, f"Severity: {result['severity']} - {', '.join(result['issues'])}")
            y_position -= 20

    c.save()

    # Upload to S3
    buffer.seek(0)
    report_key = f"compliance-report-{datetime.now().strftime('%Y%m%d-%H%M%S')}.pdf"
    s3.put_object(
        Bucket=REPORTS_BUCKET,
        Key=report_key,
        Body=buffer.getvalue(),
        ContentType='application/pdf'
    )

    return report_key
