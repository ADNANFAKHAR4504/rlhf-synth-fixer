import json
import boto3
import os

def handler(event, context):
    sns = boto3.client('sns')
    
    # Send rollback notification
    message = f"Production deployment failed. Initiating rollback procedure."
    
    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Message=message,
        Subject='Production Deployment Rollback Initiated'
    )
    
    # Add your rollback logic here
    # This could include:
    # - Reverting CloudFormation stacks
    # - Rolling back database migrations
    # - Switching traffic back to previous version
    
    return {
        'statusCode': 200,
        'body': json.dumps('Rollback initiated successfully')
    }
