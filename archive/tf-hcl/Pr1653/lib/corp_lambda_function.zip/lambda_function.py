import json
import boto3
from urllib.parse import unquote_plus

def lambda_handler(event, context):
    # Process S3 event
    s3_client = boto3.client('s3')
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])
        
        print(f"Processing object: {key} from bucket: {bucket}")
        
        try:
            # Get object metadata
            response = s3_client.head_object(Bucket=bucket, Key=key)
            print(f"Object metadata: {response}")
            
            # You can add custom processing logic here
            print(f"Successfully processed {key}")
            
        except Exception as e:
            print(f"Error processing {key}: {str(e)}")
            raise e
    
    return {
        'statusCode': 200,
        'body': json.dumps('Processing completed successfully')
    }
