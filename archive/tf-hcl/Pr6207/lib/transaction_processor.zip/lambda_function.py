import json
import boto3
import os
from datetime import datetime
from decimal import Decimal
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('REGION', 'us-east-1'))


def lambda_handler(event, context):
    """
    Transaction Processor Lambda Function
    Validates incoming transactions and stores them in DynamoDB
    """
    
    try:
        # Parse the incoming request body
        if 'body' in event:
            # API Gateway event
            transaction_data = json.loads(event['body'])
        else:
            # Direct invocation
            transaction_data = event
        
        # Validate required fields
        required_fields = ['transaction_id', 'amount', 'currency', 'merchant_id', 'timestamp']
        for field in required_fields:
            if field not in transaction_data:
                raise ValueError(f"Missing required field: {field}")
        
        # Get DynamoDB table
        table_name = os.environ.get('DYNAMODB_TABLE_NAME')
        if not table_name:
            raise ValueError("DYNAMODB_TABLE_NAME environment variable not set")
        
        table = dynamodb.Table(table_name)
        
        # Prepare item for DynamoDB
        item = {
            'transaction_id': transaction_data['transaction_id'],
            'timestamp': transaction_data['timestamp'],
            'amount': Decimal(str(transaction_data['amount'])),
            'currency': transaction_data['currency'],
            'merchant_id': transaction_data['merchant_id'],
            'processed_at': datetime.utcnow().isoformat(),
            'status': 'processed'
        }
        
        # Add any additional fields from the transaction data
        for key, value in transaction_data.items():
            if key not in item:
                if isinstance(value, float):
                    item[key] = Decimal(str(value))
                else:
                    item[key] = value
        
        # Write to DynamoDB
        table.put_item(Item=item)
        
        logger.info(f"Successfully processed transaction: {transaction_data['transaction_id']}")
        
        # Return success response
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Transaction processed successfully',
                'transaction_id': transaction_data['transaction_id'],
                'status': 'success'
            })
        }
        
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Validation error',
                'message': str(e)
            })
        }
        
    except Exception as e:
        logger.error(f"Error processing transaction: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': 'Failed to process transaction'
            })
        }