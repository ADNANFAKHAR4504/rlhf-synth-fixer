import json
import boto3
import os
from decimal import Decimal
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize SQS client
sqs = boto3.client('sqs', region_name=os.environ.get('REGION', 'us-east-1'))


def lambda_handler(event, context):
    """
    Fraud Detector Lambda Function
    Processes DynamoDB stream events and detects suspicious transactions
    """
    
    try:
        # Get SQS queue URL
        queue_url = os.environ.get('SQS_QUEUE_URL')
        if not queue_url:
            raise ValueError("SQS_QUEUE_URL environment variable not set")
        
        processed_count = 0
        suspicious_count = 0
        
        # Process each record in the DynamoDB stream
        for record in event.get('Records', []):
            try:
                # Only process INSERT and MODIFY events
                if record['eventName'] not in ['INSERT', 'MODIFY']:
                    continue
                
                # Extract transaction data from DynamoDB stream record
                if 'dynamodb' not in record or 'NewImage' not in record['dynamodb']:
                    continue
                
                new_image = record['dynamodb']['NewImage']
                transaction = convert_dynamodb_to_json(new_image)
                
                processed_count += 1
                
                # Apply fraud detection rules
                is_suspicious = detect_fraud(transaction)
                
                if is_suspicious:
                    suspicious_count += 1
                    
                    # Send suspicious transaction to SQS for manual review
                    message_body = {
                        'transaction_id': transaction.get('transaction_id'),
                        'amount': transaction.get('amount'),
                        'currency': transaction.get('currency'),
                        'merchant_id': transaction.get('merchant_id'),
                        'timestamp': transaction.get('timestamp'),
                        'fraud_indicators': get_fraud_indicators(transaction),
                        'detection_time': record['dynamodb'].get('ApproximateCreationDateTime')
                    }
                    
                    # Send message to SQS
                    sqs.send_message(
                        QueueUrl=queue_url,
                        MessageBody=json.dumps(message_body, default=str),
                        MessageAttributes={
                            'TransactionId': {
                                'StringValue': transaction.get('transaction_id', ''),
                                'DataType': 'String'
                            },
                            'FraudScore': {
                                'StringValue': 'HIGH',
                                'DataType': 'String'
                            }
                        }
                    )
                    
                    logger.info(f"Suspicious transaction sent to queue: {transaction.get('transaction_id')}")
                
            except Exception as e:
                logger.error(f"Error processing individual record: {str(e)}")
                continue
        
        logger.info(f"Processed {processed_count} transactions, {suspicious_count} flagged as suspicious")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'processed_count': processed_count,
                'suspicious_count': suspicious_count
            })
        }
        
    except Exception as e:
        logger.error(f"Error in fraud detection: {str(e)}")
        raise


def convert_dynamodb_to_json(dynamodb_item):
    """
    Convert DynamoDB item format to regular JSON
    """
    result = {}
    
    for key, value in dynamodb_item.items():
        if 'S' in value:  # String
            result[key] = value['S']
        elif 'N' in value:  # Number
            try:
                result[key] = float(value['N'])
            except ValueError:
                result[key] = value['N']
        elif 'BOOL' in value:  # Boolean
            result[key] = value['BOOL']
        elif 'NULL' in value:  # Null
            result[key] = None
        else:
            result[key] = str(value)
    
    return result


def detect_fraud(transaction):
    """
    Apply fraud detection rules to determine if transaction is suspicious
    """
    fraud_indicators = []
    
    try:
        amount = float(transaction.get('amount', 0))
        
        # Rule 1: High value transactions (>$10,000)
        if amount > 10000:
            fraud_indicators.append('high_value')
        
        # Rule 2: Very low value transactions that might be testing (<$0.01)
        if amount < 0.01:
            fraud_indicators.append('micro_transaction')
        
        # Rule 3: Round numbers might indicate suspicious activity
        if amount == int(amount) and amount >= 1000:
            fraud_indicators.append('round_amount')
        
        # Rule 4: Specific currency patterns (example: transactions in certain currencies)
        currency = transaction.get('currency', '').upper()
        high_risk_currencies = ['XBT', 'ETH', 'LTC']  # Example crypto currencies
        if currency in high_risk_currencies:
            fraud_indicators.append('high_risk_currency')
        
        # Rule 5: Merchant ID patterns (example: new or suspicious merchant)
        merchant_id = transaction.get('merchant_id', '')
        if merchant_id.startswith('TEMP_') or merchant_id.startswith('TEST_'):
            fraud_indicators.append('suspicious_merchant')
        
        # Return True if any fraud indicators are found
        return len(fraud_indicators) > 0
        
    except Exception as e:
        logger.error(f"Error in fraud detection rules: {str(e)}")
        return False


def get_fraud_indicators(transaction):
    """
    Get detailed fraud indicators for a transaction
    """
    indicators = []
    
    try:
        amount = float(transaction.get('amount', 0))
        
        if amount > 10000:
            indicators.append({
                'type': 'high_value',
                'description': f'Transaction amount ${amount:,.2f} exceeds $10,000 threshold',
                'severity': 'high'
            })
        
        if amount < 0.01:
            indicators.append({
                'type': 'micro_transaction',
                'description': f'Very low transaction amount ${amount:,.2f} may indicate testing',
                'severity': 'medium'
            })
        
        if amount == int(amount) and amount >= 1000:
            indicators.append({
                'type': 'round_amount',
                'description': f'Round amount ${amount:,.0f} may indicate suspicious activity',
                'severity': 'low'
            })
        
        currency = transaction.get('currency', '').upper()
        high_risk_currencies = ['XBT', 'ETH', 'LTC']
        if currency in high_risk_currencies:
            indicators.append({
                'type': 'high_risk_currency',
                'description': f'Transaction in high-risk currency: {currency}',
                'severity': 'high'
            })
        
        merchant_id = transaction.get('merchant_id', '')
        if merchant_id.startswith('TEMP_') or merchant_id.startswith('TEST_'):
            indicators.append({
                'type': 'suspicious_merchant',
                'description': f'Transaction from suspicious merchant: {merchant_id}',
                'severity': 'medium'
            })
        
    except Exception as e:
        logger.error(f"Error getting fraud indicators: {str(e)}")
    
    return indicators