import json
import boto3
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
eventbridge = boto3.client('events')
s3 = boto3.client('s3')

table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])
S3_BUCKET = os.environ['S3_BUCKET']

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    """Fraud scoring and risk assessment"""
    try:
        # Get transaction from DynamoDB
        transaction_id = event['transaction_id']
        response = table.get_item(Key={'transaction_id': transaction_id})

        if 'Item' not in response:
            raise Exception('Transaction not found')

        transaction = response['Item']

        # Simple fraud scoring logic (replace with ML model)
        risk_score = 0.0

        # High amount = higher risk
        if transaction['amount'] > 1000:
            risk_score += 0.3

        # International transaction = higher risk
        if transaction.get('country', 'US') != 'US':
            risk_score += 0.2

        # Update transaction with risk score
        table.update_item(
            Key={'transaction_id': transaction_id},
            UpdateExpression='SET risk_score = :score, status = :status',
            ExpressionAttributeValues={
                ':score': Decimal(str(risk_score)),
                ':status': 'scored'
            }
        )

        # If high risk, trigger EventBridge event
        if risk_score > 0.5:
            eventbridge.put_events(
                Entries=[{
                    'Source': 'fraud-detection',
                    'DetailType': 'High Risk Transaction Detected',
                    'Detail': json.dumps({
                        'transaction_id': transaction_id,
                        'risk_score': risk_score,
                        'amount': float(transaction['amount'])
                    }),
                    'EventBusName': 'default'
                }]
            )

        # Archive transaction to S3
        s3.put_object(
            Bucket=S3_BUCKET,
            Key=f'archived/{transaction_id}.json',
            Body=json.dumps(transaction, cls=DecimalEncoder)
        )

        return {
            'statusCode': 200,
            'body': json.dumps({
                'transaction_id': transaction_id,
                'risk_score': risk_score,
                'status': 'processed'
            }, cls=DecimalEncoder)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
