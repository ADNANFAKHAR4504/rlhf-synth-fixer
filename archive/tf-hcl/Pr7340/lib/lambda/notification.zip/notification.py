import json
import boto3
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    """Process fraud notifications from SQS"""
    try:
        # Process SQS messages
        for record in event['Records']:
            message = json.loads(record['body'])

            if message.get('source') == 'fraud-detection':
                transaction_id = message['transaction_id']

                # Get transaction details
                response = table.get_item(Key={'transaction_id': transaction_id})
                if 'Item' in response:
                    transaction = response['Item']

                    # Send notification (placeholder - integrate with actual notification system)
                    notification_message = {
                        'type': 'fraud_alert',
                        'transaction_id': transaction_id,
                        'risk_score': float(transaction['risk_score']),
                        'amount': float(transaction['amount']),
                        'merchant': transaction['merchant_id'],
                        'timestamp': transaction['timestamp']
                    }

                    # Publish to SNS for further processing
                    sns.publish(
                        TopicArn=os.environ.get('SNS_TOPIC_ARN', 'arn:aws:sns:us-east-1:123456789012:fraud-alerts'),
                        Message=json.dumps(notification_message, cls=DecimalEncoder),
                        Subject='High Risk Transaction Alert'
                    )

                    # Update transaction status
                    table.update_item(
                        Key={'transaction_id': transaction_id},
                        UpdateExpression='SET status = :status',
                        ExpressionAttributeValues={':status': 'notified'}
                    )

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Notifications processed successfully'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
