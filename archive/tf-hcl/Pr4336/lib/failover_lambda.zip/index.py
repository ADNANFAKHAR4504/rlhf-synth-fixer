import json
import boto3
import os
import time
from datetime import datetime

def handler(event, context):
    """
    Orchestrate failover to secondary region
    """
    print(f"Failover initiated at {datetime.utcnow()}")
    print(f"Event: {json.dumps(event)}")
    
    secondary_region = os.environ['SECONDARY_REGION']
    secondary_db_id = os.environ['SECONDARY_DB_ID']
    hosted_zone_id = os.environ['HOSTED_ZONE_ID']
    domain_name = os.environ['DOMAIN_NAME']
    
    # Initialize AWS clients
    rds_client = boto3.client('rds', region_name=secondary_region)
    route53_client = boto3.client('route53')
    cloudwatch = boto3.client('cloudwatch')
    
    response = {
        'statusCode': 200,
        'steps': []
    }
    
    try:
        # Step 1: Promote RDS Read Replica
        print(f"Promoting read replica: {secondary_db_id}")
        rds_response = rds_client.promote_read_replica(
            DBInstanceIdentifier=secondary_db_id,
            BackupRetentionPeriod=30
        )
        response['steps'].append({
            'step': 'RDS Promotion',
            'status': 'Initiated',
            'db_status': rds_response['DBInstance']['DBInstanceStatus']
        })
        
        # Step 2: Wait for promotion to complete
        waiter = rds_client.get_waiter('db_instance_available')
        waiter.wait(
            DBInstanceIdentifier=secondary_db_id,
            WaiterConfig={
                'Delay': 30,
                'MaxAttempts': 20
            }
        )
        response['steps'].append({
            'step': 'RDS Promotion',
            'status': 'Completed'
        })
        
        # Step 3: Update Route53 if needed
        # The failover routing policy should handle this automatically
        # This is a placeholder for additional DNS updates if required
        
        # Step 4: Send CloudWatch metrics
        cloudwatch.put_metric_data(
            Namespace='DisasterRecovery',
            MetricData=[
                {
                    'MetricName': 'FailoverExecuted',
                    'Value': 1,
                    'Unit': 'Count',
                    'Timestamp': datetime.utcnow()
                }
            ]
        )
        
        response['message'] = 'Failover completed successfully'
        
    except Exception as e:
        print(f"Error during failover: {str(e)}")
        response['statusCode'] = 500
        response['error'] = str(e)
        
        # Send failure metric
        cloudwatch.put_metric_data(
            Namespace='DisasterRecovery',
            MetricData=[
                {
                    'MetricName': 'FailoverFailed',
                    'Value': 1,
                    'Unit': 'Count',
                    'Timestamp': datetime.utcnow()
                }
            ]
        )
    
    return response
