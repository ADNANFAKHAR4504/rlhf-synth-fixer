import json
import boto3
import os

def handler(event, context):
    sns = boto3.client('sns')
    
    # Process security event
    print(f"Processing security event: {json.dumps(event)}")
    
    # Send notification
    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Subject='Security Alert: Unauthorized Access Attempt',
        Message=f'Security event detected: {json.dumps(event)}'
    )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Security response completed')
    }
