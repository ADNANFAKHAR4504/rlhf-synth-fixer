/**
 * AWS Batch Job Orchestrator Lambda Function
 * Orchestrates batch processing jobs for financial transactions
 */

// AWS SDK v3 is included in nodejs20.x runtime
const { BatchClient, SubmitJobCommand } = require('@aws-sdk/client-batch');
const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');
const { S3Client, ListObjectsV2Command } = require('@aws-sdk/client-s3');
const { SNSClient, PublishCommand } = require('@aws-sdk/client-sns');

const batchClient = new BatchClient({ region: process.env.AWS_REGION });
const dynamoClient = new DynamoDBClient({ region: process.env.AWS_REGION });
const s3Client = new S3Client({ region: process.env.AWS_REGION });
const snsClient = new SNSClient({ region: process.env.AWS_REGION });

const JOB_QUEUE = process.env.JOB_QUEUE;
const JOB_DEFINITION = process.env.JOB_DEFINITION;
const DYNAMODB_TABLE = process.env.DYNAMODB_TABLE;
const SNS_TOPIC = process.env.SNS_TOPIC;
const INPUT_BUCKET = process.env.INPUT_BUCKET;
const TRANSACTIONS_PER_JOB = parseInt(
  process.env.TRANSACTIONS_PER_JOB || '10000'
);

/**
 * Lambda handler - orchestrates batch job submission
 */
exports.handler = async event => {
  console.log('Event received:', JSON.stringify(event, null, 2));

  try {
    // List files in input bucket
    const listCommand = new ListObjectsV2Command({
      Bucket: INPUT_BUCKET,
      Prefix: 'transactions/',
    });

    const response = await s3Client.send(listCommand);
    const files = response.Contents || [];

    if (files.length === 0) {
      console.log('No files to process in input bucket');
      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'No files to process' }),
      };
    }

    console.log(`Found ${files.length} files to process`);

    // Submit batch jobs for each file
    const jobSubmissions = [];
    for (const file of files) {
      if (file.Size === 0) continue; // Skip empty files

      const jobName = `financial-batch-${Date.now()}-${Math.random().toString(36).substring(7)}`;
      const jobId = `job-${Date.now()}-${Math.random().toString(36).substring(7)}`;

      // Submit batch job
      const submitJobCommand = new SubmitJobCommand({
        jobName: jobName,
        jobQueue: JOB_QUEUE,
        jobDefinition: JOB_DEFINITION,
        containerOverrides: {
          environment: [
            { name: 'INPUT_FILE', value: file.Key },
            { name: 'INPUT_BUCKET', value: INPUT_BUCKET },
            { name: 'JOB_ID', value: jobId },
          ],
        },
      });

      const submitResponse = await batchClient.send(submitJobCommand);
      console.log(`Submitted job ${submitResponse.jobId} for file ${file.Key}`);

      // Record job status in DynamoDB
      const putItemCommand = new PutItemCommand({
        TableName: DYNAMODB_TABLE,
        Item: {
          JobId: { S: submitResponse.jobId },
          JobName: { S: jobName },
          Status: { S: 'SUBMITTED' },
          InputFile: { S: file.Key },
          SubmittedAt: { S: new Date().toISOString() },
          TransactionsCount: { N: '0' },
          ProcessedCount: { N: '0' },
          ErrorCount: { N: '0' },
        },
      });

      await dynamoClient.send(putItemCommand);
      jobSubmissions.push({
        jobId: submitResponse.jobId,
        jobName: jobName,
        inputFile: file.Key,
      });
    }

    // Send notification
    const snsMessage = {
      Message: JSON.stringify({
        event: 'BatchJobsSubmitted',
        timestamp: new Date().toISOString(),
        jobCount: jobSubmissions.length,
        jobs: jobSubmissions,
      }),
      Subject: `Batch Processing Started - ${jobSubmissions.length} jobs submitted`,
      TopicArn: SNS_TOPIC,
    };

    await snsClient.send(new PublishCommand(snsMessage));

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Batch jobs submitted successfully',
        jobCount: jobSubmissions.length,
        jobs: jobSubmissions,
      }),
    };
  } catch (error) {
    console.error('Error processing batch jobs:', error);

    // Send error notification
    try {
      await snsClient.send(
        new PublishCommand({
          Message: JSON.stringify({
            event: 'BatchJobSubmissionFailed',
            timestamp: new Date().toISOString(),
            error: error.message,
            stack: error.stack,
          }),
          Subject: 'Batch Processing Error',
          TopicArn: SNS_TOPIC,
        })
      );
    } catch (snsError) {
      console.error('Failed to send SNS notification:', snsError);
    }

    throw error;
  }
};
