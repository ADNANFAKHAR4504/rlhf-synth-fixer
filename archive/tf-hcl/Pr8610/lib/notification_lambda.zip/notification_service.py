import json
import boto3
import os
from datetime import datetime

def lambda_handler(event, context):
    try:
        body = event.get('body')
        if body:
            body = json.loads(body)
        
        # Mock notification sending
        notification_type = body.get('type', 'email')
        recipient = body.get('recipient', 'default@example.com')
        message = body.get('message', 'Default notification message')
        
        # Simulate notification sending
        response_body = {
            'notification_id': f'notif_{datetime.utcnow().strftime("%Y%m%d_%H%M%S")}',
            'type': notification_type,
            'recipient': recipient,
            'message': message,
            'status': 'sent',
            'sent_at': datetime.utcnow().isoformat()
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response_body)
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': str(e),
                'message': 'Failed to send notification'
            })
        }
