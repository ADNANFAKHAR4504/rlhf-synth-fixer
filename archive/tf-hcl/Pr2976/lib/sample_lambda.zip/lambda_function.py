import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Process SNS message
    if 'Records' in event:
        for record in event['Records']:
            if record.get('EventSource') == 'aws:sns':
                message = record['Sns']['Message']
                logger.info(f"Processing SNS message: {message}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from TAP Stack Lambda!')
    }
