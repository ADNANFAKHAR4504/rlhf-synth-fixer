// index.js - Lambda function for log processing
const AWS = require('aws-sdk');
const cloudwatch = new AWS.CloudWatch();
const s3 = new AWS.S3();

// Environment variables from Lambda configuration
const LOG_BUCKET = process.env.LOG_BUCKET;
const METRIC_NAMESPACE = process.env.METRIC_NAMESPACE;

/**
 * Main handler function for processing logs from Kinesis Firehose
 */
exports.handler = async (event, context) => {
  console.log('Processing log batch with ID:', context.awsRequestId);

  const records = event.records;
  const processedRecords = [];

  // Metrics to track
  let totalLogs = 0;
  let errorCount = 0;
  let securityEventCount = 0;
  let performanceEventCount = 0;
  let serverMetrics = {};

  try {
    // Process each record in the batch
    for (const record of records) {
      try {
        totalLogs++;

        // Decode and parse the record
        const buffer = Buffer.from(record.data, 'base64');
        const decodedData = buffer.toString('utf-8');

        // Parse log data (assuming JSON)
        let logData;
        try {
          logData = JSON.parse(decodedData);
        } catch (err) {
          // Handle non-JSON logs
          logData = {
            message: decodedData,
            timestamp: new Date().toISOString(),
            log_level: decodedData.includes('ERROR') ? 'ERROR' : 'INFO',
            parsed: false,
          };
        }

        // Extract log source from Firehose metadata
        const logSource = extractLogSource(record);

        // Enrich log data
        logData.processing_time = new Date().toISOString();
        logData.log_source = logSource || 'unknown';

        // Track metrics based on log content
        if (isErrorLog(logData)) {
          errorCount++;
        }

        if (isSecurityEvent(logData, logSource)) {
          securityEventCount++;
        }

        if (isPerformanceEvent(logData, logSource)) {
          performanceEventCount++;
        }

        // Track per-server metrics
        if (logData.server_id) {
          if (!serverMetrics[logData.server_id]) {
            serverMetrics[logData.server_id] = {
              logCount: 0,
              errorCount: 0,
            };
          }

          serverMetrics[logData.server_id].logCount++;

          if (isErrorLog(logData)) {
            serverMetrics[logData.server_id].errorCount++;
          }
        }

        // Add structured data for better analysis
        logData.year = new Date().getFullYear();
        logData.month = new Date().getMonth() + 1;
        logData.day = new Date().getDate();
        logData.hour = new Date().getHours();

        // Convert processed log back to base64
        const processedData = Buffer.from(JSON.stringify(logData)).toString(
          'base64'
        );

        // Add to processed records
        processedRecords.push({
          recordId: record.recordId,
          result: 'Ok',
          data: processedData,
        });
      } catch (err) {
        console.error('Error processing record:', err);
        errorCount++;

        // If processing fails, return the original record
        processedRecords.push({
          recordId: record.recordId,
          result: 'ProcessingFailed',
          data: record.data,
        });
      }
    }

    // Send metrics to CloudWatch
    await sendCloudWatchMetrics(
      totalLogs,
      errorCount,
      securityEventCount,
      performanceEventCount,
      serverMetrics
    );

    // For important events, store a summary in S3 for audit purposes
    if (errorCount > 0 || securityEventCount > 0) {
      await storeAuditSummary(context.awsRequestId, {
        timestamp: new Date().toISOString(),
        requestId: context.awsRequestId,
        totalLogs,
        errorCount,
        securityEventCount,
        performanceEventCount,
      });
    }

    console.log(
      `Processed ${totalLogs} logs, found ${errorCount} errors, ${securityEventCount} security events`
    );

    // Return the processed records back to Firehose
    return { records: processedRecords };
  } catch (err) {
    console.error('Fatal error in log processor:', err);
    throw err;
  }
};

/**
 * Extract log source from the Kinesis Firehose record
 */
function extractLogSource(record) {
  if (
    record.kinesisRecordMetadata &&
    record.kinesisRecordMetadata.deliveryStreamArn
  ) {
    const streamArn = record.kinesisRecordMetadata.deliveryStreamArn;
    const streamName = streamArn.split('/').pop();

    // Extract log type from delivery stream name pattern
    const logTypeMatch = streamName.match(/-([^-]+)-stream$/);
    return logTypeMatch ? logTypeMatch[1] : null;
  }
  return null;
}

/**
 * Determine if a log entry is an error based on its content
 */
function isErrorLog(logData) {
  if (logData.log_level) {
    return ['ERROR', 'FATAL', 'SEVERE', 'CRITICAL'].includes(
      logData.log_level.toUpperCase()
    );
  }

  if (logData.level) {
    return ['ERROR', 'FATAL', 'SEVERE', 'CRITICAL'].includes(
      logData.level.toUpperCase()
    );
  }

  if (logData.message) {
    return (
      logData.message.includes('error') ||
      logData.message.includes('exception') ||
      logData.message.includes('fail') ||
      logData.message.includes('critical')
    );
  }

  return false;
}

/**
 * Determine if a log entry is a security event
 */
function isSecurityEvent(logData, logSource) {
  if (logSource === 'security') {
    return true;
  }

  const message = logData.message || '';
  return (
    message.includes('authentication') ||
    message.includes('login') ||
    message.includes('password') ||
    message.includes('permission') ||
    message.includes('access denied') ||
    message.includes('unauthorized') ||
    message.includes('firewall')
  );
}

/**
 * Determine if a log entry is a performance event
 */
function isPerformanceEvent(logData, logSource) {
  if (logSource === 'performance') {
    return true;
  }

  const message = logData.message || '';
  return (
    message.includes('latency') ||
    message.includes('timeout') ||
    message.includes('slow') ||
    message.includes('memory') ||
    message.includes('cpu') ||
    message.includes('performance')
  );
}

/**
 * Send metrics to CloudWatch
 */
async function sendCloudWatchMetrics(
  totalLogs,
  errorCount,
  securityEventCount,
  performanceEventCount,
  serverMetrics
) {
  const timestamp = new Date();

  // Helper function to ensure valid metric values
  const sanitizeValue = (value) => {
    if (value === null || value === undefined || isNaN(value) || !isFinite(value)) {
      return 0;
    }
    return Math.max(0, Math.floor(value)); // Ensure positive integers
  };

  // Prepare metric data with sanitized values
  const metricData = [
    {
      MetricName: 'ProcessedLogCount',
      Value: sanitizeValue(totalLogs),
      Unit: 'Count',
      Timestamp: timestamp,
    },
    {
      MetricName: 'ErrorCount',
      Value: sanitizeValue(errorCount),
      Unit: 'Count',
      Timestamp: timestamp,
    },
    {
      MetricName: 'SecurityEventCount',
      Value: sanitizeValue(securityEventCount),
      Unit: 'Count',
      Timestamp: timestamp,
    },
    {
      MetricName: 'PerformanceEventCount',
      Value: sanitizeValue(performanceEventCount),
      Unit: 'Count',
      Timestamp: timestamp,
    },
  ];

  // Add per-server metrics with sanitized values
  for (const [serverId, metrics] of Object.entries(serverMetrics || {})) {
    if (metrics && typeof metrics === 'object') {
      metricData.push(
        {
          MetricName: 'ServerLogCount',
          Value: sanitizeValue(metrics.logCount),
          Unit: 'Count',
          Timestamp: timestamp,
          Dimensions: [{ Name: 'ServerId', Value: String(serverId) }],
        },
        {
          MetricName: 'ServerErrorCount',
          Value: sanitizeValue(metrics.errorCount),
          Unit: 'Count',
          Timestamp: timestamp,
          Dimensions: [{ Name: 'ServerId', Value: String(serverId) }],
        }
      );
    }
  }

  // Send metrics in batches (maximum 20 per request)
  for (let i = 0; i < metricData.length; i += 20) {
    const batch = metricData.slice(i, i + 20);

    try {
      await cloudwatch
        .putMetricData({
          Namespace: METRIC_NAMESPACE,
          MetricData: batch,
        })
        .promise();
    } catch (err) {
      console.error('Error sending CloudWatch metrics:', err);
    }
  }
}

/**
 * Store audit summary in S3 for important events
 */
async function storeAuditSummary(requestId, summaryData) {
  const date = new Date();
  const year = date.getFullYear();
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');

  const key = `audit-summaries/${year}/${month}/${day}/${requestId}.json`;

  try {
    await s3
      .putObject({
        Bucket: LOG_BUCKET,
        Key: key,
        Body: JSON.stringify(summaryData, null, 2),
        ContentType: 'application/json',
      })
      .promise();
  } catch (err) {
    console.error('Error storing audit summary:', err);
  }
}
