const { Client } = require('pg');

exports.handler = async (event) => {
  console.log('Processing payment:', JSON.stringify(event));
        
  const client = new Client({
    host: process.env.DB_HOST.split(':')[0],
    port: 5432,
    database: process.env.DB_NAME,
    user: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
  });

  try {
    await client.connect();
    const result = await client.query('SELECT NOW()');
    console.log('Database connection successful:', result.rows[0]);
          
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Payment processed successfully',
        timestamp: result.rows[0].now
      })
    };
  } catch (error) {
    console.error('Error:', error);
    throw error;
  } finally {
    await client.end();
  }
};
