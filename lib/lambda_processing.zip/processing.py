import json

def handler(event, context):
    """Processing handler"""
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Processing executed'})
    }
