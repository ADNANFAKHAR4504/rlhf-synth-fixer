import json

def handler(event, context):
    """Processing Lambda handler"""
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Processing successful', 'event': event})
    }
