import json
import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    # Process S3 event
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        logger.info(f"Processing object {key} from bucket {bucket}")
        
        # Your application logic here
        # Example: Get environment variables from SSM/Secrets Manager
        ssm = boto3.client('ssm')
        try:
            response = ssm.get_parameter(
                Name=f"/{os.environ['PROJECT_NAME']}/{os.environ['ENVIRONMENT']}/app-config",
                WithDecryption=True
            )
            config = response['Parameter']['Value']
            logger.info("Retrieved configuration from SSM")
        except Exception as e:
            logger.error(f"Failed to retrieve configuration: {str(e)}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Successfully processed S3 event')
    }
