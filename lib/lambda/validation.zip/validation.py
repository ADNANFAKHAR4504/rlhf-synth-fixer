import json
import boto3
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    """Transaction validation and storage"""
    try:
        # Get transaction data from API Gateway
        body = json.loads(event['body'])
        transaction_id = body['transaction_id']

        # Store transaction in DynamoDB
        transaction = {
            'transaction_id': transaction_id,
            'timestamp': body.get('timestamp', '2024-01-01T00:00:00Z'),
            'amount': Decimal(str(body.get('amount', 0))),
            'currency': body.get('currency', 'USD'),
            'merchant_id': body.get('merchant_id', 'unknown'),
            'card_last_four': body.get('card_last_four', '****'),
            'status': 'pending',
            'risk_score': 0.0
        }

        table.put_item(Item=transaction)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Transaction validated and stored',
                'transaction_id': transaction_id
            }, cls=DecimalEncoder)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
