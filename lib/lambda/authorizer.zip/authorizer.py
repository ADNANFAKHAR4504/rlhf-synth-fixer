import json
import os

def lambda_handler(event, context):
    """Token authorizer for API Gateway"""
    try:
        # Extract token from Authorization header
        token = event.get('authorizationToken', '')

        # Simple token validation (replace with actual logic)
        if not token or token != os.environ.get('EXPECTED_TOKEN', 'valid-token'):
            raise Exception('Unauthorized')

        # Return IAM policy document
        return {
            'principalId': 'user',
            'policyDocument': {
                'Version': '2012-10-17',
                'Statement': [
                    {
                        'Action': 'execute-api:Invoke',
                        'Effect': 'Allow',
                        'Resource': event['methodArn']
                    }
                ]
            }
        }
    except Exception as e:
        raise Exception('Unauthorized')
